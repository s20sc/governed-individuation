# Cross-family rule coding v1

Completed one fresh Gemini-family blind semantic annotation. Primary report: [analysis-report.md](analysis-report.md). Result: 63/64 exact cell agreement; one retained scope disagreement outside the tested cells; all 64 downstream assignments unchanged. Frozen raw data and original Codex ledger preserved. This is post-hoc AI agreement evidence, not human gold or a whole-paper review verdict.

For arithmetic reproduction, run the unchanged `../pairing-stage-fidelity-v1/recompute.py` against the existing pilot export and `gemini-literal-rule-annotations.json`, with a fresh output directory. Exact invocation/exit status are in `reader-run.json`. Its `analysis.json` is authoritative for the arithmetic; its inherited Codex-specific `report.md` boilerplate is not this annotation's provenance. New provenance, convention, disagreements and native terminal evidence are kept separately here.
