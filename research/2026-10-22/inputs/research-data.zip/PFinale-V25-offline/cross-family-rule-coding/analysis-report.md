# Cross-family blind semantic validation

## Question and input blinding

Does a second model family reproduce the explicit-clause annotations of the eight generated rules, and would any disagreement alter the downstream error partition? The frozen protocol and prompt predate the new labels. A fresh native Gemini Argon session received the full raw rules under neutral IDs and the coding convention. Original Codex labels, target mappings, downstream events, paper text and audit reports were withheld from the supplied prompt. All raw texts match the original wire responses. Native metadata contains one initial prompt and one final response, one generation, and no observed tool step. This is input blinding in an isolated working directory, not an OS access sandbox or proof about model training data.

## Result

Exact action-set and qualification agreement is **63/64 (98.4375%)**. Seven rule texts agree on all 8 cells; one agrees on 7/8. The sole disagreement is **rule-2-reference / Marten / owned=false / public=false**. The original ledger preserves scope ambiguity between admit and defer. Gemini codes defer, reading “public is true or false” as one coordinated predicate within the owned=true condition. Both judgments and the quoted raw text remain available; no consensus label replaces either one.

| Full rule-cell category | Original Codex | Blind Gemini |
|---|---:|---:|
| Singleton agrees with supplied mapping | 30 | 31 |
| Singleton contradicts supplied mapping | 22 | 22 |
| Silent | 10 | 10 |
| Conflicting clauses | 1 | 1 |
| Scope ambiguity | 1 | 0 |
| Total | 64 | 64 |

The disagreement is outside the **32 distinct tested cells**. Recomputing against all original retained records confirms **all 64 downstream events and their category counts are identical**. Among 56 singleton events, 49 choices equal the literal constraint and 7 do not. Of 37 mapping errors, 27 equal an incorrect explicit constraint, 2 differ from a correct constraint, and 8 concern silence/conflict. The five remaining disagreements with incorrect constraints match the supplied mapping. This checks robustness of this descriptive partition to one independent model-family annotation; it does not establish hidden rule following or causal mediation.

Figure 1 locates the single semantic disagreement; Figure 2 verifies its lack of downstream impact. This makes the existing stage diagnosis better supported while preserving its interpretation-dependent nature.

## Evidence and limits

- `protocol.md`, `blind-prompt.txt`, `input-manifest.json`: frozen question, convention, raw-text/ledger identities.
- `native-result.json`, `terminal.json`, `verification.json`: complete SUCCESS response, exit 0, one generation, exact quoted spans and all 64 unique cells. Requested/executor alias gemini-4-argon-high; native generation strings also include gemini-4-argon-trial/M417. Do not infer an independently authenticated backend version from aliases.
- `blind-annotations.json`, `gemini-literal-rule-annotations.json`, `disagreements.json`: complete new labels, neutral-ID mapping and the one disagreement.
- `event-propagation.json`: exact full-cell and downstream comparison.
- `unchanged-reader-output/analysis.json`: recomputation by the unchanged reviewed stage reader, including source/terminal bindings. That reader's generated `report.md` contains inherited Codex-specific provenance boilerplate and must not be cited as provenance for this new annotation. This report and the new ledger notes provide the actual provenance.

This is one post-hoc AI annotator per model family (plus the earlier within-Codex check), not human annotation, an independently verified semantic oracle, replicated generation or new policy samples. All 152/128 collection records remain unchanged. No retry, service/configuration change or public release occurred. The reviewer findings require original-seat reassessment; this evidence does not by itself close their verdicts.
