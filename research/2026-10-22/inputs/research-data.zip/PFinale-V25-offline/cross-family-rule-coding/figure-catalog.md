# Figure interpretation

## Figure 1: cell agreement

Files: `figures/figure-01-cell-agreement.pdf` and `.png`. Source: original and blind ledgers, all 64 cells. Axes: original Codex vs blind Gemini categories; values are exact counts. No error bars: finite census, not an estimated population rate. Caption: “Cross-family literal-clause coding of eight retained rule texts. One scope-ambiguous cell is coded as defer by the blind annotator; both readings are retained.” Notice the single off-diagonal entry. It identifies exactly where interpretation remains unresolved, rather than claiming semantic gold.

## Figure 2: downstream alignment

Files: `figures/figure-02-downstream-alignment.pdf` and `.png`. Source: unchanged stage reader on both ledgers and the original 152-attempt archive; 64 events, 32 distinct tested cells. Paired bars give finite counts under each ledger. No error bars and no independent-sample claim. Caption: “The retained choice–constraint partition is identical under both annotations because the only disputed cell is not tested downstream.” Notice identical counts in every category. This supports retaining the existing descriptive error partition but adds no evidence about causal internal rule following.
