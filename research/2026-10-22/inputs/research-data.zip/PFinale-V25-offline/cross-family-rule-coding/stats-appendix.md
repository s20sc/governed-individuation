# Statistical scope

Finite census: 8 retained rule texts x 2 operators x 4 Boolean patterns = 64 cells. Repeated downstream observations cover only 32 distinct rule/operator/pattern cells, with two document IDs each = 64 events. These are not 64 independent policies or annotator replications.

Exact matching uses both the sorted action set and qualification. Agreement 63/64 = 98.4375%; disagreement 1/64 = 1.5625%. Per-text agreements are seven 8/8 and one 7/8 (rule-2-reference). Changed event assignments = 0/64. New full-ledger counts differ by +1 agreeing singleton and -1 scope ambiguity; all other count differences are zero. These finite differences are the descriptive effect sizes.

No population confidence interval, significance test, seed-level standard deviation or multiple-comparison correction is reported: no stochastic sampling design or independent annotation repetitions supports one. The requested comparison is an exact census and event propagation, not a population accuracy claim. All supplied texts and the pre-result protocol are retained. Disagreement is preserved without majority-vote adjudication.
