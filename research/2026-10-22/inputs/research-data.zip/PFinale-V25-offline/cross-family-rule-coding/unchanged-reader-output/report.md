# Eight retained generated rules: literal fidelity and application

Post-hoc Codex-assisted semantic transcription, checked by another Codex reviewer; not human annotation, independent semantic gold, or a new model experiment. Silence is not filled with an unstated default; scope ambiguity and conflicting clauses are retained.

| Rule text | Agrees / 8 | Contradicts / 8 | Silent / 8 | Conflict / 8 | Ambiguous / 8 |
|---|---:|---:|---:|---:|---:|
|rule-3-flipped|4|2|2|0|0|
|rule-3-reference|7|0|1|0|0|
|rule-2-reference|5|3|0|0|0|
|rule-0-flipped|3|4|1|0|0|
|rule-1-reference|4|2|2|0|0|
|rule-0-reference|2|2|4|0|0|
|rule-2-flipped|2|6|0|0|0|
|rule-1-flipped|4|3|0|1|0|

| Visible rule status | Downstream relation | Supplied-mapping agreement | Decisions |
|---|---|---|---:|
|agrees_with_supplied|disagrees_with_literal_rule|False|2|
|agrees_with_supplied|follows_literal_rule|True|22|
|conflicting_clauses|not_identified|False|2|
|contradicts_supplied|disagrees_with_literal_rule|True|5|
|contradicts_supplied|follows_literal_rule|False|27|
|silent|not_identified|False|6|

Every full quoted clause, all64operator/attribute annotations and all64downstream events are in analysis.json. The stored follows_literal_rule label denotes only choice equality with a singleton literal constraint; it does not establish that the model followed that clause internally. These are reused fixed policies and patterns, not independent policy samples. Visible disagreement with a literal rule does not identify hidden model reasoning, and no counterfactual rule replacement was run.
