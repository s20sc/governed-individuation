#120accepted BEHAVIOR cases: portable recorded-cost recomputation

Work on a fresh extracted/copy directory. From this directory run `python3 -B analyze.py`; it exclusively creates `recorded-cost-results.json` and will not overwrite an existing result. Compare it byte-for-byte with `expected/recorded-cost-results.json`. All runtime, simulator and network operations are absent from this previously reviewed144-line analyzer. Original source and480rawinputs are exact copies.

The original `frozen-inputs.json` is under`provenance/`. The operational copy changes only its `archive` locator to `metrics/aeros-behavior-2026-final120-20261010.zip`; its120cases, expected archive/member hashes and remote identity metadata are identical. Run from this directory because that one relative archive locator resolves from the working directory; raw files resolve beside the original analyzer. The adaptation is recorded in`locator-change-receipt.json`.

Expected:120qualified,0missing/invalid,79556gatecalls,288209.58summed evaluator elapsedseconds; server gate/write/finalize totals remain separately labelled. They are not totalcampaigncost, inferencecounts, GPUtime, energy, causaloverhead, or trustedclock/signature evidence. No model or simulator is started. Do not run recovery scripts or modify originals.

A zero exit status alone is insufficient: require120qualified and0missing/invalid, plus byte equality with the preserved expectedresult. The original reader deliberately reports missing/tampered individualrecords as invalid and may still exit0; changed/missingrecords must not be treated as completedcoverage or zero measurement.
