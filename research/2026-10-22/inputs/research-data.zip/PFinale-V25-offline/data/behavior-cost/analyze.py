"""Recompute recorded evaluator and server counters from qualified originals.

No causal inference, signature/clock authentication or end-to-end cost claim.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import shlex
import statistics
import zipfile
from decimal import Decimal
from pathlib import Path

HERE=Path(__file__).resolve().parent
FIELDS=["gate_calls","gate_seconds","audit_record_write_seconds","audit_stream_finalize_seconds"]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def nonnegative(value: object) -> float:
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0:
        raise ValueError("invalid nonnegative finite measurement")
    return float(value)


def elapsed_seconds(text: str) -> Decimal:
    if not re.fullmatch(r"\d+:\d{2}(?::\d{2})?(?:\.\d+)?",text):
        raise ValueError("invalid elapsed format")
    parts=[Decimal(x) for x in text.split(":")]
    if parts[-1]>=60 or (len(parts)==3 and parts[1]>=60):
        raise ValueError("invalid elapsed component")
    return sum((p*m for p,m in zip(reversed(parts),[1,60,3600])),Decimal(0))


def parse_footer(text: str, item: dict) -> dict:
    marker='Command being timed: '
    if text.count(marker)!=1:
        raise ValueError("exactly one evaluator time footer required")
    footer=text.split(marker,1)[1]
    command=footer.splitlines()[0]
    if not (command.startswith('"') and command.endswith('"')):
        raise ValueError("unrecognized evaluator command quoting")
    args=shlex.split(command[1:-1])
    if any(arg.startswith("--") and "=" in arg for arg in args):
        raise ValueError("equals-style command flags are outside archived split syntax")
    if args[:3] != ["python","-m","omnigibson.eval.eval"]:
        raise ValueError("different timed executable")
    expected={"--task-name":item["case"]["task"],"--instance-indices":str(item["case"]["instance"]),"--num-rollouts":"1","--policy":"websocket","--mode":"public_test","--env-wrapper":"omnigibson.eval.wrappers.RGBDFullResWrapper","--output-dir":item["remote_dir"],"--robot-config":item["remote_dir"]+"/robot.yaml"}
    for key,value in expected.items():
        if args.count(key)!=1 or args.index(key)+1>=len(args) or args[args.index(key)+1]!=value:
            raise ValueError(f"timed command identity differs: {key}")
    def unique(label: str) -> str:
        matches=re.findall(r"^\s*"+re.escape(label)+r": (.+)$",footer,re.MULTILINE)
        if len(matches)!=1:
            raise ValueError(f"missing or repeated footer field: {label}")
        return matches[0].strip()
    if unique("Exit status")!="0":
        raise ValueError("timed evaluator did not exit0")
    elapsed=elapsed_seconds(unique("Elapsed (wall clock) time (h:mm:ss or m:ss)"))
    def numeric(label: str) -> Decimal:
        value=unique(label)
        if not re.fullmatch(r"\d+(?:\.\d+)?",value):
            raise ValueError("invalid numeric footer time")
        return Decimal(value)
    cpu_user=numeric("User time (seconds)"); cpu_system=numeric("System time (seconds)")
    for x in [elapsed,cpu_user,cpu_system]:
        if not x.is_finite() or x<0:
            raise ValueError("invalid footer time")
    return {"evaluator_elapsed_seconds":str(elapsed),"evaluator_user_cpu_seconds":str(cpu_user),"evaluator_system_cpu_seconds":str(cpu_system)}


def parse_runtime(data: dict) -> dict:
    if set(data)!=set(FIELDS+["scope"]) or not isinstance(data["scope"],str):
        raise ValueError("unexpected timer schema")
    if isinstance(data["gate_calls"],bool) or not isinstance(data["gate_calls"],int):
        raise ValueError("gate_calls must be an integer counter")
    for name in FIELDS: nonnegative(data[name])
    return data.copy()


def load_record(item: dict, package: zipfile.ZipFile, config: dict) -> dict:
    """Rebind originals independently of the acquisition ledger's verdict fields."""
    directory=HERE/"raw"/f"{item['ordinal']:03}"
    raw=(directory/"rollout.signed.json").read_bytes()
    if digest(raw)!=item["index"]["signed_manifest_sha256"]:
        raise ValueError("envelope no longer matches archive index")
    env=json.loads(raw); doc=env["document"]; manifest=json.loads(package.read("task_manifest.json"))
    if doc["identity"]["task"]!=item["case"]["task"] or doc["identity"]["image_id"]!=manifest["image"] or env["public_key_sha256"]!=manifest["key_fingerprint"]:
        raise ValueError("envelope identity mismatch")
    metricpath=item["index"]["metrics_path"]; metric=package.read("metrics/"+Path(metricpath).name)
    if digest(metric)!=item["index"]["metrics_sha256"] or doc["artifacts"][metricpath]!={"bytes":len(metric),"sha256":digest(metric)}:
        raise ValueError("metric artifact mismatch")
    files={}
    for relative in ["server/runtime_timing.json","run_manifest.json","eval.log"]:
        content=(directory/relative).read_bytes(); expected=doc["artifacts"][relative]
        if len(content)!=expected["bytes"] or digest(content)!=expected["sha256"]:
            raise ValueError(f"raw artifact mismatch: {relative}")
        files[relative]=content
    run=json.loads(files["run_manifest.json"])
    if run["spec"]!=item["case"] or run["protocol_sha256"]!=config["task_manifest_sha256"] or run["image"]!=manifest["image"] or run["key_fingerprint"]!=manifest["key_fingerprint"]:
        raise ValueError("run manifest mismatch")
    timing=parse_runtime(json.loads(files["server/runtime_timing.json"]))
    timing.update(parse_footer(files["eval.log"].decode(),item))
    return {"ordinal":item["ordinal"],"task":item["case"]["task"],"accepted_attempt":item["index"]["attempt"],"run_id":doc["identity"]["run_id"],"status":"qualified",**timing}


def summarize(rows: list[dict]) -> dict:
    qualified=[r for r in rows if r["status"]=="qualified"]
    result={"selected_records":len(rows),"qualified_records":len(qualified),"missing_or_invalid_records":len(rows)-len(qualified),"scope":"descriptive recorded measures for identity-qualified accepted records; totals are not complete campaign/system/GPU costs","fields":{}}
    for name in FIELDS+["evaluator_elapsed_seconds","evaluator_user_cpu_seconds","evaluator_system_cpu_seconds"]:
        vals=[Decimal(str(r[name])) for r in qualified]
        if not vals:
            result["fields"][name]={"n":0};continue
        floats=[float(v) for v in vals]
        result["fields"][name]={"n":len(vals),"sum":str(sum(vals,Decimal(0))),"mean":statistics.mean(floats),"sample_sd":statistics.stdev(floats) if len(vals)>1 else None,"median":statistics.median(floats),"min":min(floats),"max":max(floats),"all_selected_covered":len(vals)==len(rows)}
    return result


def main() -> None:
    config=json.loads((HERE/"frozen-inputs.json").read_text()); archive=Path(config["archive"])
    if digest(archive.read_bytes())!=config["archive_sha256"]:
        raise ValueError("archive identity drift")
    rows=[]
    with zipfile.ZipFile(archive) as package:
        if digest(package.read("task_manifest.json"))!=config["task_manifest_sha256"] or digest(package.read("artifact_index.json"))!=config["artifact_index_sha256"]:
            raise ValueError("archive member identity drift")
        if [r["case"] for r in config["cases"]]!=json.loads(package.read("task_manifest.json"))["cases"] or [r["index"] for r in config["cases"]]!=json.loads(package.read("artifact_index.json")):
            raise ValueError("frozen selection drift")
        for item in config["cases"]:
            try:
                rows.append(load_record(item,package,config))
            except (OSError,ValueError,KeyError,TypeError) as error:
                rows.append({"ordinal":item["ordinal"],"task":item["case"]["task"],"status":"missing_or_invalid","error_type":type(error).__name__,"error":str(error)})
    result={"summary":summarize(rows),"tasks":{t:summarize([r for r in rows if r["task"]==t]) for t in dict.fromkeys(r["task"] for r in rows)},"timer_scope_strings":sorted(set(r["scope"] for r in rows if r["status"]=="qualified")),"records":rows,"not_established":["timer insertion/overlap and clock trust","model request count","episode-only/every-process cost","GPU time/energy","incomplete attempt and cold bootstrap/campaign costs","digital signature and physical-effect authentication","CN01/DR02/C2/B closure"]}
    with (HERE/"recorded-cost-results.json").open("x") as handle:
        json.dump(result,handle,ensure_ascii=False,indent=2);handle.write("\n")


if __name__=="__main__":main()
