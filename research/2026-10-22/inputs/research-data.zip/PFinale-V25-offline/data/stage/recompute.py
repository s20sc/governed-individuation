"""Post-hoc literal-rule ledger and retained-choice alignment; offline only."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


PLAN_SHA = 'd3983a0b17ada80df101afcd540962cf0ae80dc6de974c9c2c2bdde63b1b6834'
TERMINAL_SHA = 'c5236f99553a553c2631ec2492754edc867300a508cfde0eaa2f286a31ebfa9f'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def recompute(collection: Path, annotations: Path, output: Path) -> None:
    frozen = collection / ('frozen-20261019' if (collection/'frozen-20261019').exists() else 'frozen')
    run = collection / ('run-20261019' if (collection/'run-20261019').exists() else 'run')
    if sha(frozen/'plan.json') != PLAN_SHA or sha(run/'terminal.json') != TERMINAL_SHA:
        raise ValueError('not the reviewed finite campaign')
    terminal = read(run/'terminal.json')
    for binding in terminal['files']:
        name = binding['path']
        if not isinstance(name, str) or Path(name).name != name or '\\' in name:
            raise ValueError('invalid raw file binding')
        if sha(run/name) != binding['sha256']:
            raise ValueError('retained raw record changed')
    plan = read(frozen/'plan.json')
    ledger = read(annotations)
    lookup = {}
    full_cells = []
    expected_rule_jobs = {j['id'] for j in plan['jobs'] if j['kind']=='rule'}
    annotated_rules = set()
    for rule in ledger['rules']:
        rid = rule['job']
        if rid not in expected_rule_jobs or rid in annotated_rules:
            raise ValueError('unexpected or repeated annotated rule')
        annotated_rules.add(rid)
        text = read(run/(rid+'.wire.json'))['response']
        if hashlib.sha256(text.encode()).hexdigest() != rule['raw_text_sha256']:
            raise ValueError('annotated rule text changed')
        condition = rid.rsplit('-', 1)[-1]
        for operator in rule['operators']:
            op = operator['operator']
            if not operator['quotes'] or any(q not in text for q in operator['quotes']):
                raise ValueError('quoted evidence not in complete raw rule')
            for cell in operator['cells']:
                if type(cell['owned']) is not bool or type(cell['public']) is not bool:
                    raise ValueError('non-Boolean annotation')
                key = (rid, op, cell['owned'], cell['public'])
                if key in lookup:
                    raise ValueError('duplicate annotated cell')
                matching = [r for r in plan['dataset']['train'] if r['operator']==op
                            and r['owned']==cell['owned'] and r['public']==cell['public']]
                if len(matching) != 1:
                    raise ValueError('annotation outside frozen training table')
                target = matching[0][condition+'_choice']
                actions = cell['action_constraints']
                qualification = cell['qualification']
                if qualification == 'singleton':
                    if actions not in (['admit'], ['defer']):
                        raise ValueError('invalid singleton action')
                    status = 'agrees_with_supplied' if actions[0]==target else 'contradicts_supplied'
                elif qualification == 'silent' and actions == []:
                    status = 'silent'
                elif qualification in ('ambiguous_scope', 'conflicting_clauses') and actions == ['admit','defer']:
                    status = qualification
                else:
                    raise ValueError('inconsistent annotation qualification')
                row = {'rule': rid, 'operator': op, **cell, 'supplied_choice': target,
                       'literal_status': status, 'quotes': operator['quotes']}
                lookup[key] = row
                full_cells.append(row)
    if annotated_rules != expected_rule_jobs or len(lookup) != 64:
        raise ValueError('incomplete eight-rule, 64-cell ledger')
    events = []
    for job in plan['jobs']:
        if job['kind'] != 'decision' or not job.get('rule_id'):
            continue
        if terminal['states'][job['id']] != 'done':
            raise ValueError('incomplete generated-rule decision')
        response = read(run/(job['id']+'.wire.json'))
        # These fixed reviewed responses contain exactly one binary choice.
        parsed = json.loads(response['response'])
        if not isinstance(parsed, dict) or set(parsed) != {'choice'} or parsed['choice'] not in ('admit','defer'):
            raise ValueError('expected complete binary-valid retained decisions')
        test = job['test']
        cell = lookup[(job['rule_id'],test['operator'],test['owned'],test['public'])]
        action = parsed['choice']
        application = ('follows_literal_rule' if action==cell['action_constraints'][0]
                       else 'disagrees_with_literal_rule') if cell['qualification']=='singleton' else 'not_identified'
        events.append({'job':job['id'], 'rule':job['rule_id'], 'operator':test['operator'],
                       'owned':test['owned'], 'public':test['public'], 'choice':action,
                       'literal_status':cell['literal_status'], 'application':application,
                       'supplied_choice':test[job['condition']+'_choice'],
                       'supplied_mapping_agreement':action==test[job['condition']+'_choice']})
    if len(events) != 64:
        raise ValueError('expected 64 generated-rule downstream decisions')
    categories = Counter((e['literal_status'],e['application'],e['supplied_mapping_agreement']) for e in events)
    table = [{'literal_status':s, 'application':a, 'supplied_mapping_agreement':g, 'n':n}
             for (s,a,g),n in sorted(categories.items())]
    summary = {'scope':'post-hoc literal-clause analysis; not hidden reasoning or causal mediation',
               'annotation_notes':ledger['notes'], 'training_cells':len(full_cells),
               'training_literal_status_counts':dict(Counter(c['literal_status'] for c in full_cells)),
               'downstream_decisions':len(events),
               'downstream_literal_status_counts':dict(Counter(e['literal_status'] for e in events)),
               'alignment_categories':table, 'full_training_ledger':full_cells,
               'downstream_events':events}
    output.mkdir()  # All input checks precede output; existing output is preserved.
    with (output/'analysis.json').open('x',encoding='utf-8') as stream:
        json.dump(summary,stream,ensure_ascii=False,indent=2)
        stream.write('\n')
    rows = ['# Eight retained generated rules: literal fidelity and application', '',
            'Post-hoc Codex-assisted semantic transcription, checked by another Codex reviewer; not human annotation, independent semantic gold, or a new model experiment. Silence is not filled with an unstated default; scope ambiguity and conflicting clauses are retained.', '',
            '| Rule text | Agrees / 8 | Contradicts / 8 | Silent / 8 | Conflict / 8 | Ambiguous / 8 |',
            '|---|---:|---:|---:|---:|---:|']
    for rid in [r['job'] for r in ledger['rules']]:
        counts = Counter(c['literal_status'] for c in full_cells if c['rule']==rid)
        rows.append('|'+rid+'|'+'|'.join(str(counts[s]) for s in ('agrees_with_supplied','contradicts_supplied','silent','conflicting_clauses','ambiguous_scope'))+'|')
    rows += ['', '| Visible rule status | Downstream relation | Supplied-mapping agreement | Decisions |',
             '|---|---|---|---:|']
    rows += [f"|{r['literal_status']}|{r['application']}|{r['supplied_mapping_agreement']}|{r['n']}|" for r in table]
    rows += ['', 'Every full quoted clause, all64operator/attribute annotations and all64downstream events are in analysis.json. The stored follows_literal_rule label denotes only choice equality with a singleton literal constraint; it does not establish that the model followed that clause internally. These are reused fixed policies and patterns, not independent policy samples. Visible disagreement with a literal rule does not identify hidden model reasoning, and no counterfactual rule replacement was run.', '']
    (output/'report.md').write_text('\n'.join(rows),encoding='utf-8')
    bindings = [frozen/'plan.json',run/'terminal.json',annotations,Path(__file__)]
    manifest = {'inputs':[{'path':str(p),'sha256':sha(p)} for p in bindings],
                'outputs':[{'path':p.name,'sha256':sha(p)} for p in sorted(output.iterdir())]}
    with (output/'manifest.json').open('x',encoding='utf-8') as stream:
        json.dump(manifest,stream,indent=2)
        stream.write('\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('collection',type=Path)
    parser.add_argument('annotations',type=Path)
    parser.add_argument('output',type=Path)
    args = parser.parse_args()
    recompute(args.collection,args.annotations,args.output)
