# Frozen finite pilot: descriptive results

Single installed Qwen2.5:7b Q4_K_M; eight fixed decisions, two Boolean attribute patterns, four order/seed blocks. Reference policy is hidden from the model; disagreement is not a verified authorisation failure. No actions were executed.

Run status: done; generation attempts 152/152; retries 0; observed decisions 144/144.

| Block | Arm | Ref disagreement or invalid / planned | Invalid / observed | Supplied mapping agreement / observed | Joint reference twins / 4 |
|---|---|---|---|---|---|
|0|generated-flipped|4/8 (8 observed)|0/8|4/8|0/4|
|0|generated-reference|5/8 (8 observed)|0/8|3/8|0/4|
|0|direct-flipped|5/8 (8 observed)|0/8|5/8|0/4|
|0|direct-reference|2/8 (8 observed)|0/8|6/8|2/4|
|1|generated-flipped|2/8 (8 observed)|0/8|2/8|2/4|
|1|generated-reference|4/8 (8 observed)|0/8|4/8|0/4|
|1|direct-reference|2/8 (8 observed)|0/8|6/8|2/4|
|1|direct-flipped|5/8 (8 observed)|0/8|5/8|0/4|
|2|generated-reference|6/8 (8 observed)|0/8|2/8|0/4|
|2|generated-flipped|2/8 (8 observed)|0/8|2/8|2/4|
|2|direct-flipped|6/8 (8 observed)|0/8|6/8|0/4|
|2|direct-reference|1/8 (8 observed)|0/8|7/8|3/4|
|3|generated-flipped|4/8 (8 observed)|0/8|4/8|0/4|
|3|generated-reference|2/8 (8 observed)|0/8|6/8|2/4|
|3|direct-flipped|4/8 (8 observed)|0/8|4/8|0/4|
|3|direct-reference|2/8 (8 observed)|0/8|6/8|2/4|
|anchor|none|5/8 (8 observed)|0/8|N/A|0/4|
|anchor|generic|4/8 (8 observed)|0/8|N/A|0/4|

Only complete four-arm blocks have an interaction; missing decisions are never filled with zero.

| Block | Direct flip contrast | Generated flip contrast | Interaction |
|---|---|---|---|
|0|0.375|-0.125|-0.500|
|1|0.375|-0.250|-0.625|
|2|0.625|-0.500|-1.125|
|3|0.250|0.250|0.000|

cells.csv includes reference-admit/reference-defer strata and invalids with fixed planned denominators, plus explicitly labelled valid-only fractions. analysis.json retains each task/block event. rules.json retains full generated texts; costs.json retains reported counts and durations. Full rules and direct prompts differ in generation and length: any interaction concerns these bundled pipelines, not an isolated compression mechanism. Anchors have one block, and no supplied policy. No population, equivalence, priority or INS-readiness claim follows from this table.
